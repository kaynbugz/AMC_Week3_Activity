import React from 'react';
import {StyleSheet, TextInput} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInputExample = () => {
  const [text, onChangeText] = React.useState('NAME: ');
  const [age, onChangeNumber] = React.useState('AGE: ');
  const [address, onChangeaddress] = React.useState('Address: ')
  const [school, onChangeschool] = React.useState('School: ')
  const [course, onChangecourse] = React.useState('Course: ')
  const [email, onChangeemail] = React.useState('Email: ')
  const [ContactNo, onChangecontactno] = React.useState('Contact No: ')
  


  return (
    <SafeAreaProvider>
      <SafeAreaView>
        <TextInput
          style={styles.input}
          onChangeText={onChangeText}
          value={text}
        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeNumber}
          value={age}
          placeholder="useless placeholder"
          keyboardType="numeric"
        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeaddress}
          value={address}
        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeschool}
          value={school}
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangecourse}
          value={course}
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangeemail}
          value={email}
        />    
          <TextInput
          style={styles.input}
          onChangeText={onChangecontactno}
          value={ContactNo}
        />
        
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
});

export default TextInputExample;