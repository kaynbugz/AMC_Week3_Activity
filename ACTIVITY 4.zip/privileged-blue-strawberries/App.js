import React from 'react';
import {StyleSheet, TextInput, View} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';
import { Image } from 'react-native';

const TextInputExample = () => {
  const [text, onChangeText] = React.useState('NAME: ');
  const [age, onChangeNumber] = React.useState('AGE: ');
  const [address, onChangeaddress] = React.useState('Address: ');
  const [school, onChangeschool] = React.useState('School: ');
  const [course, onChangecourse] = React.useState('Course: ');
  const [email, onChangeemail] = React.useState('Email: ');
  const [ContactNo, onChangecontactno] = React.useState('Contact No: ');
  const [border, onChangeborder] = React.useState('About Me: ');

  return (
    <SafeAreaProvider>
      <SafeAreaView>
        <View style={styles.row}>
       <Image source={{uri: 'https://th.bing.com/th/id/OIP.Izz-T7h8tBKMx0q9nA8bUQHaIz?rs=1&pid=ImgDetMain'}}
            style={{width: 40, height: 50, marginTop: 10, marginLeft: 15}} />
      <TextInput  
            style={styles.input}
          onChangeText={onChangeText}
            value={text}
          />
        </View>
        <View style={styles.row}>
        <Image source={{uri: 'https://th.bing.com/th/id/OIP.W_YdpQSnxBbWFSk3fuWewQHaHa?rs=1&pid=ImgDetMain'}}
            style={{width: 40, height: 50, marginTop: 10, marginLeft: 15}} />
       <TextInput
            style={styles.input}
            onChangeText={onChangeNumber}
            value={age}
            placeholder="useless placeholder"
            keyboardType="numeric"
          />
        </View>
     <View style={styles.row}>
     <Image source={{uri: 'https://i.pinimg.com/736x/e8/3e/bf/e83ebf39ce627157dd59736e5f4aaa5c.jpg'}}
            style={{width: 40, height: 50, marginTop: 10, marginLeft: 15}} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeaddress}
            value={address}
          />
        </View>
        <View style={styles.row}>
        <Image source={{uri: 'https://th.bing.com/th/id/OIP.XsX1bv_1rkeJbK7GCSnORgAAAA?rs=1&pid=ImgDetMain'}}
            style={{width: 40, height: 50, marginTop: 10, marginLeft: 15}} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeschool}
            value={school}
          />
        </View>
        <View style={styles.row}>
        <Image source={{uri: 'https://th.bing.com/th/id/OIP.FcktM9S_h_Ava8JHqcGD3gHaFp?rs=1&pid=ImgDetMain'}}
            style={{width: 40, height: 50, marginTop: 10, marginLeft: 15}} />
          <TextInput
            style={styles.input}
            onChangeText={onChangecourse}
            value={course}
          />
        </View>
        <View style={styles.row}>
        <Image source={{uri: 'https://th.bing.com/th/id/OIP.ItJAPcsiwqhE-5Fb35tW6QHaEK?w=1920&h=1080&rs=1&pid=ImgDetMain'}}
            style={{width: 40, height: 50, marginTop: 10, marginLeft: 15}} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeemail}
            value={email}
          />    
        </View>
        <View style={styles.row}>
        <Image source={{uri: 'https://th.bing.com/th/id/OIP.yxx1roSjMbioVebYjosJjQAAAA?w=400&h=300&rs=1&pid=ImgDetMain'}}
            style={{width: 40, height: 50, marginTop: 10, marginLeft: 15}} />
         <TextInput
            style={styles.input}
            onChangeText={onChangecontactno} 
            value={ContactNo}
          />
        </View>
        <View style={styles.row}>
  <Image source={{uri: 'https://i.pinimg.com/originals/7e/dc/6f/7edc6fc0e013a9a36a2e2ffcb3e2ea2b.jpg'}}
            style={{width: 40, height: 50, marginTop: 10, marginLeft: 15}} />
  <TextInput
        editable
          multiline
          numberOfLines={4}
          maxLength={100}
          onChangeText={border => onChangeborder(border)}
          value={border}
          style={styles.container}
        />
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 10,
    borderWidth: 2,
    width: 300,
  },
  container: {
    borderBottomColor: '#000',
    borderWidth: 2,
    margin: 12,
    marginTop: 1,
    marginRight: 20,
    marginLeft: 10,
    width: 525,
  },
  textInput: {
    padding: 15,
  },
  row: {
    flexDirection: 'row',
    marginBottom: 10,
  },
});

export default TextInputExample;
